package com.lampac.tv

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import org.json.JSONObject

class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private lateinit var splash: ImageView
    private val started = System.currentTimeMillis()
    private val prefs by lazy { getSharedPreferences("lampa", MODE_PRIVATE) }

    // id -> підпис у меню
    private val players = listOf(
        "exo" to "ExoPlayer (вбудований)",
        "web" to "Плеєр Lampa (веб)",
        "vlc" to "VLC",
        "mx" to "MX Player",
        "vimu" to "Vimu",
        "system" to "Вибір системи"
    )

    // Перехоплює Lampa.Player.play і віддає відео в застосунок.
    private val hookJs = """
        (function(){
          if(window.__lampacHooked) return;
          var t=setInterval(function(){
            if(window.Lampa&&Lampa.Player&&Lampa.Player.play){
              clearInterval(t);
              if(window.__lampacHooked) return;
              window.__lampacHooked=true;
              try{LampacNative.hooked()}catch(e){}
              var o=Lampa.Player.play;
              window.__lampacOrig=function(d){return o.call(Lampa.Player,d)};
              Lampa.Player.play=function(d){
                try{
                  if(d&&typeof d.url==='string'&&/^https?:/.test(d.url)){
                    window.__lampacLast=d;
                    var p=(d.playlist||[]).map(function(i){return {url:i.url,title:i.title}});
                    var tl=d.timeline?{time:d.timeline.time,duration:d.timeline.duration}:null;
                    LampacNative.play(d.url,JSON.stringify({url:d.url,title:d.title,playlist:p,timeline:tl}));
                    return;
                  }
                }catch(e){}
                return o.apply(this,arguments);
              };
            }
          },500);
        })();
    """.trimIndent()

    private fun pluginsJs(): String {
        val urls = BuildConfig.PLUGINS.split(",").map { it.trim() }.filter { it.startsWith("http") }
        if (urls.isEmpty()) return ""
        val arr = urls.joinToString(",") { "'" + it.replace("'", "") + "'" }
        return "(function(){window.__lampacPl=window.__lampacPl||{};[$arr].forEach(function(u){" +
            "if(window.__lampacPl[u])return;window.__lampacPl[u]=1;" +
            "var s=document.createElement('script');s.src=u;s.async=true;document.head.appendChild(s);});})();"
    }

    private val playerLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            val d = r.data ?: return@registerForActivityResult
            val pos = d.getLongExtra("pos", 0)
            val dur = d.getLongExtra("dur", 0)
            web.evaluateJavascript("window.__lampacProgress&&window.__lampacProgress($pos,$dur)", null)
        }

    private fun hideSplash() {
        val wait = (1500 - (System.currentTimeMillis() - started)).coerceAtLeast(0)
        splash.postDelayed({
            splash.animate().alpha(0f).setDuration(400)
                .withEndAction { splash.visibility = View.GONE }.start()
        }, wait)
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this).apply {
            setBackgroundColor(0xFF000000.toInt())
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                mediaPlaybackRequiresUserGesture = false
                mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                if (BuildConfig.NATIVE_BRIDGE) userAgentString = userAgentString + " lampa_client"
            }
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(v: WebView?, url: String?) {
                    v?.evaluateJavascript(hookJs, null)
                    v?.evaluateJavascript(pluginsJs(), null)
                    hideSplash()
                }
                override fun onReceivedError(v: WebView?, r: WebResourceRequest?, e: WebResourceError?) {
                    if (r?.isForMainFrame == true) hideSplash()
                }
            }
            webChromeClient = WebChromeClient()
            addJavascriptInterface(NativeApi(), "LampacNative")
            if (BuildConfig.NATIVE_BRIDGE) addJavascriptInterface(Bridge(), "AndroidJS")
            isFocusable = true
            requestFocus()
        }
        splash = ImageView(this).apply {
            setImageResource(R.drawable.splash)
            scaleType = ImageView.ScaleType.CENTER_CROP
        }
        setContentView(FrameLayout(this).apply {
            addView(web, FrameLayout.LayoutParams(-1, -1))
            addView(splash, FrameLayout.LayoutParams(-1, -1))
        })
        hideSystemUi()
        web.loadUrl(BuildConfig.SERVER_URL)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript(
                    "(window.Lampa&&Lampa.Controller)?(Lampa.Controller.back(),'ok'):'no'"
                ) { res -> if (res?.contains("no") == true) finish() }
            }
        })
    }

    // ---------- вибір плеєра ----------

    private fun playWith(id: String, url: String, json: String?) {
        val o = runCatching { JSONObject(json ?: "{}") }.getOrDefault(JSONObject())
        val title = o.optString("title")
        val posMs = ((o.optJSONObject("timeline")?.optDouble("time", 0.0) ?: 0.0) * 1000).toLong()
        when (id) {
            "web" -> web.evaluateJavascript(
                "window.__lampacOrig&&window.__lampacLast&&window.__lampacOrig(window.__lampacLast)", null)
            "vlc" -> external(url, title, posMs, "org.videolan.vlc")
            "mx" -> external(url, title, posMs, "com.mxtech.videoplayer.pro", "com.mxtech.videoplayer.ad")
            "vimu" -> external(url, title, posMs, "net.gtvbox.videoplayer")
            "system" -> startActivity(
                Intent.createChooser(
                    Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(url), "video/*")
                        .putExtra("title", title), "Відкрити у плеєрі"))
            else -> playerLauncher.launch(
                Intent(this, PlayerActivity::class.java).putExtra("url", url).putExtra("json", json))
        }
    }

    private fun external(url: String, title: String, posMs: Long, vararg pkgs: String) {
        for (p in pkgs) {
            try {
                startActivity(Intent(Intent.ACTION_VIEW).setPackage(p)
                    .setDataAndType(Uri.parse(url), "video/*")
                    .putExtra("title", title).putExtra("position", posMs.toInt()))
                return
            } catch (_: ActivityNotFoundException) { }
        }
        Toast.makeText(this, "Плеєр не встановлено, відкриваю вбудований", Toast.LENGTH_LONG).show()
        playerLauncher.launch(Intent(this, PlayerActivity::class.java)
            .putExtra("url", url)
            .putExtra("json", JSONObject().put("url", url).put("title", title).toString()))
    }

    private fun onPlay(url: String, json: String?) {
        val saved = prefs.getString("player", "ask") ?: "ask"
        if (saved != "ask") { playWith(saved, url, json); return }
        val names = players.map { it.second }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Відкрити у плеєрі")
            .setItems(names) { _, i -> playWith(players[i].first, url, json) }
            .setNeutralButton("Налаштувати") { _, _ -> showDefaultPicker() }
            .show()
    }

    /** Плеєр за замовчуванням: ask = питати щоразу. Відкривається кнопкою MENU/SETTINGS на пульті. */
    private fun showDefaultPicker() {
        val items = listOf("ask" to "Питати щоразу") + players
        val cur = items.indexOfFirst { it.first == prefs.getString("player", "ask") }.coerceAtLeast(0)
        AlertDialog.Builder(this).setTitle("Плеєр за замовчуванням")
            .setSingleChoiceItems(items.map { it.second }.toTypedArray(), cur) { d, i ->
                prefs.edit().putString("player", items[i].first).apply()
                d.dismiss()
                Toast.makeText(this, items[i].second, Toast.LENGTH_SHORT).show()
            }.show()
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if ((e.keyCode == KeyEvent.KEYCODE_MENU || e.keyCode == KeyEvent.KEYCODE_SETTINGS)) {
            if (e.action == KeyEvent.ACTION_UP) showDefaultPicker()
            return true
        }
        return super.dispatchKeyEvent(e)
    }

    private fun hideSystemUi() {
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemUi()
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }

    inner class NativeApi {
        @JavascriptInterface
        fun play(url: String, json: String?) { runOnUiThread { onPlay(url, json) } }

        @JavascriptInterface
        fun hooked() {
            runOnUiThread {
                Toast.makeText(this@MainActivity, "Вибір плеєра активний", Toast.LENGTH_SHORT).show()
            }
        }
    }

    /** Експериментальна емуляція AndroidJS (вимкнена: BuildConfig.NATIVE_BRIDGE=false). */
    inner class Bridge {
        @JavascriptInterface
        fun openPlayer(url: String, json: String?) { runOnUiThread { playWith("exo", url, json) } }
        @JavascriptInterface fun appVersion(): String = "2.0.0-999"
        @JavascriptInterface fun exit() { runOnUiThread { finish() } }
        @JavascriptInterface fun clearCache(all: Boolean) { runOnUiThread { web.clearCache(true) } }
    }
}
