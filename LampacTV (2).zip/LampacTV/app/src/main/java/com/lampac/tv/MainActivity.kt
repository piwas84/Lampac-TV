package com.lampac.tv

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : ComponentActivity() {
    private lateinit var web: WebView

    private val playerLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            val d = r.data ?: return@registerForActivityResult
            val pos = d.getLongExtra("pos", 0)
            val dur = d.getLongExtra("dur", 0)
            // Хук для вашого плагіна: window.__lampacProgress(posMs, durMs)
            web.evaluateJavascript("window.__lampacProgress&&window.__lampacProgress($pos,$dur)", null)
        }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this).apply {
            setBackgroundColor(0xFF000000.toInt())
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                mediaPlaybackRequiresUserGesture = false
                mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                if (BuildConfig.NATIVE_BRIDGE) userAgentString = userAgentString + " lampa_client"
            }
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
            if (BuildConfig.NATIVE_BRIDGE) addJavascriptInterface(Bridge(), "AndroidJS")
            isFocusable = true
            requestFocus()
        }
        setContentView(web)
        hideSystemUi()
        web.loadUrl(BuildConfig.SERVER_URL)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript(
                    "(window.Lampa&&Lampa.Controller)?(Lampa.Controller.back(),'ok'):'no'"
                ) { res -> if (res?.contains("no") == true) finish() }
            }
        })
    }

    private fun hideSystemUi() {
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemUi()
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }

    /** Мінімальний аналог AndroidJS з офіційного Lampa для Android. */
    inner class Bridge {
        @JavascriptInterface
        fun openPlayer(url: String, json: String?) {
            runOnUiThread {
                playerLauncher.launch(
                    Intent(this@MainActivity, PlayerActivity::class.java)
                        .putExtra("url", url).putExtra("json", json)
                )
            }
        }

        @JavascriptInterface fun appVersion(): String = "2.0.0-999"
        @JavascriptInterface fun exit() { runOnUiThread { finish() } }
        @JavascriptInterface fun clearCache(all: Boolean) { runOnUiThread { web.clearCache(true) } }
    }
}
