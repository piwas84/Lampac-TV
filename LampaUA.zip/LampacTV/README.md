# Lampac TV
WebView з вашим Lampac + рідний ExoPlayer (Android TV / приставки).

Збірка: відкрити папку в Android Studio -> Build -> Build APK(s)
або `gradle assembleDebug` (APK: app/build/outputs/apk/debug/).
Адреса сервера: app/build.gradle.kts -> SERVER_URL.
У Lampa: Налаштування -> Плеєр -> вибрати «Android» (якщо не обрано автоматично).

## Збірка через GitHub Actions
Завантажте проєкт у репозиторій GitHub -> вкладка Actions -> Build APK -> Run workflow.
Після завершення APK буде в Artifacts (LampacTV-debug-apk).

## Вибір плеєра
При запуску відео з'являється меню (ExoPlayer, веб-плеєр Lampa, VLC, MX Player, Vimu, вибір системи).
Кнопка MENU/SETTINGS на пульті: плеєр за замовчуванням ("Питати щоразу" або конкретний).
