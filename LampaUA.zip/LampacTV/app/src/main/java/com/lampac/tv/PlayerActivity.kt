package com.lampac.tv

import android.content.Intent
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import org.json.JSONObject

class PlayerActivity : ComponentActivity() {
    private var player: ExoPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val view = PlayerView(this).apply { setShowSubtitleButton(true) }
        setContentView(view)

        val url = intent.getStringExtra("url") ?: return finish()
        val json = intent.getStringExtra("json")
            ?.let { runCatching { JSONObject(it) }.getOrNull() }

        val items = mutableListOf<MediaItem>()
        var start = -1
        json?.optJSONArray("playlist")?.let { pl ->
            for (i in 0 until pl.length()) {
                val o = pl.optJSONObject(i) ?: continue
                val u = o.optString("url")
                if (u.isEmpty()) continue
                if (u == url) start = items.size
                items.add(item(u, o.optString("title")))
            }
        }
        if (start < 0) { items.add(0, item(url, json?.optString("title"))); start = 0 }

        val seekMs = ((json?.optJSONObject("timeline")?.optDouble("time", 0.0) ?: 0.0) * 1000).toLong()

        player = ExoPlayer.Builder(this).build().also { p ->
            view.player = p
            p.setMediaItems(items, start, seekMs)
            p.prepare()
            p.playWhenReady = true
        }
    }

    private fun item(u: String, title: String?) = MediaItem.Builder()
        .setUri(u)
        .setMediaMetadata(MediaMetadata.Builder().setTitle(title).build())
        .build()

    override fun finish() {
        player?.let {
            setResult(RESULT_OK, Intent()
                .putExtra("pos", it.currentPosition)
                .putExtra("dur", it.duration.coerceAtLeast(0)))
        }
        super.finish()
    }

    override fun onStop() { super.onStop(); player?.pause() }
    override fun onDestroy() { player?.release(); player = null; super.onDestroy() }
}
